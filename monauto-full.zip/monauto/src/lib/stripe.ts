// src/lib/stripe.ts
import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-10-28.acacia',
  typescript: true,
})

export const PREMIUM_PRICE = parseInt(process.env.PREMIUM_REPORT_PRICE ?? '990') // cents

export async function createCheckoutSession(
  estimationId: string,
  userId: string,
  userEmail: string,
  successUrl: string,
  cancelUrl: string,
) {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'payment',
    customer_email: userEmail,
    line_items: [
      {
        price_data: {
          currency: 'eur',
          unit_amount: PREMIUM_PRICE,
          product_data: {
            name: 'Rapport Premium MonAuto',
            description: 'Analyse complète : décote, coûts, conseils expert',
            images: [`${process.env.NEXT_PUBLIC_APP_URL}/og-premium.png`],
          },
        },
        quantity: 1,
      },
    ],
    metadata: {
      estimationId,
      userId,
    },
    success_url: successUrl,
    cancel_url:  cancelUrl,
  })

  return session
}
