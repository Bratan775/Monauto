// src/lib/estimation-engine.ts

export interface EstimationInput {
  brand: string
  model: string
  year: number
  mileage: number
  fuel: string
  condition: string
}

export interface EstimationResult {
  priceLow: number
  priceMid: number
  priceHigh: number
  dealScore: number
  depreciation1y: number
  depreciation2y: number
  annualFuelCost: number
  annualMaintCost: number
  marketTrend: 'up' | 'stable' | 'down'
  advice: string
}

// Base prices per brand/category (EUR) - simulated market database
const BRAND_MULTIPLIERS: Record<string, number> = {
  'Tesla': 1.35, 'BMW': 1.30, 'Mercedes': 1.32, 'Audi': 1.28,
  'Porsche': 1.85, 'Lexus': 1.25, 'Volvo': 1.20, 'Land Rover': 1.40,
  'Volkswagen': 1.10, 'Toyota': 1.12, 'Honda': 1.08, 'Mazda': 1.05,
  'Hyundai': 1.00, 'Kia': 1.00, 'Skoda': 1.02, 'Seat': 0.98,
  'Peugeot': 0.98, 'Renault': 0.96, 'Citroën': 0.94, 'Ford': 0.97,
  'Opel': 0.93, 'Fiat': 0.90, 'Dacia': 0.82, 'Nissan': 0.97,
}

// Annual depreciation rate by age
function getDepreciationRate(age: number): number {
  if (age <= 1)  return 0.18  // 18% first year
  if (age <= 2)  return 0.14
  if (age <= 3)  return 0.12
  if (age <= 4)  return 0.10
  if (age <= 5)  return 0.09
  if (age <= 7)  return 0.08
  if (age <= 10) return 0.07
  return 0.05
}

// Fuel type adjustments
const FUEL_ADJUSTMENTS: Record<string, number> = {
  'hybride':    1.08,
  'electrique': 1.05,  // slightly reduced due to battery concerns
  'essence':    1.00,
  'diesel':     0.93,  // diesel penalty in FR cities
  'gpl':        0.88,
  'hydrogene':  1.15,
}

// Condition adjustments
const CONDITION_ADJUSTMENTS: Record<string, { low: number; mid: number; high: number }> = {
  'excellent': { low: 1.05, mid: 1.10, high: 1.15 },
  'tres-bon':  { low: 0.97, mid: 1.02, high: 1.07 },
  'bon':       { low: 0.88, mid: 0.93, high: 0.99 },
  'moyen':     { low: 0.72, mid: 0.80, high: 0.88 },
  'mauvais':   { low: 0.52, mid: 0.62, high: 0.72 },
}

// Mileage adjustment: expected vs actual
function getMileageAdjustment(year: number, mileage: number): number {
  const currentYear = new Date().getFullYear()
  const age = currentYear - year
  const expectedMileage = age * 15000  // average 15k/year in France
  const ratio = mileage / Math.max(expectedMileage, 1)

  if (ratio < 0.5)  return 1.12   // very low mileage bonus
  if (ratio < 0.7)  return 1.06
  if (ratio < 0.9)  return 1.02
  if (ratio < 1.1)  return 1.00   // normal
  if (ratio < 1.3)  return 0.95
  if (ratio < 1.6)  return 0.88
  if (ratio < 2.0)  return 0.80
  return 0.70  // very high mileage
}

// Model-specific base prices (EUR new) - representative values
const MODEL_BASE_PRICES: Record<string, number> = {
  // Renault
  'Clio': 18500, 'Mégane': 24000, 'Captur': 25000, 'Kadjar': 28000,
  'Koleos': 35000, 'Zoe': 30000, 'Kangoo': 22000, 'Trafic': 34000,
  // Peugeot
  '208': 20000, '308': 26000, '2008': 27000, '3008': 34000,
  '5008': 40000, 'e-208': 35000, 'Partner': 23000,
  // Volkswagen
  'Polo': 21000, 'Golf': 28000, 'Passat': 36000, 'T-Roc': 30000,
  'Tiguan': 38000, 'Touareg': 65000, 'Transporter': 38000,
  // BMW
  'Série 1': 34000, 'Série 2': 38000, 'Série 3': 46000, 'Série 5': 60000,
  'X1': 40000, 'X3': 52000, 'X5': 75000, 'X6': 80000,
  // Mercedes
  'Classe A': 35000, 'Classe C': 50000, 'Classe E': 65000,
  'GLA': 42000, 'GLC': 58000, 'GLE': 78000,
  // Audi
  'A1': 28000, 'A3': 36000, 'A4': 44000, 'A6': 58000,
  'Q2': 32000, 'Q3': 38000, 'Q5': 52000, 'Q7': 72000,
  // Tesla
  'Model 3': 48000, 'Model Y': 55000, 'Model S': 90000, 'Model X': 95000,
  // Toyota
  'Yaris': 20000, 'Corolla': 28000, 'RAV4': 38000, 'C-HR': 32000,
  // Others
  'Duster': 19000, 'Qashqai': 30000, 'Octavia': 26000,
  'Leon': 25000, 'i30': 24000,
}

// Annual fuel cost by type (EUR, avg 15k km/year)
const ANNUAL_FUEL_COST: Record<string, number> = {
  'essence':    1800,
  'diesel':     1400,
  'hybride':    1100,
  'hybride-rechargeable': 800,
  'electrique': 650,
  'gpl':        1200,
  'hydrogene':  2200,
}

// Annual maintenance cost by brand tier
function getAnnualMaintCost(brand: string, age: number, fuel: string): number {
  const isEV = fuel === 'electrique'
  const isPremium = ['BMW', 'Mercedes', 'Audi', 'Porsche', 'Lexus', 'Volvo'].includes(brand)
  const isReliable = ['Toyota', 'Honda', 'Mazda', 'Lexus'].includes(brand)

  let base = isPremium ? 1400 : isReliable ? 600 : 900
  if (isEV) base *= 0.6  // lower maintenance for EV
  if (age > 8) base *= 1.4
  else if (age > 5) base *= 1.2
  else if (age > 3) base *= 1.1

  return Math.round(base)
}

export function calculateEstimation(input: EstimationInput): EstimationResult {
  const currentYear = new Date().getFullYear()
  const age = currentYear - input.year
  
  if (age < 0 || age > 30) {
    throw new Error('Année invalide')
  }

  // 1. Get base price (new vehicle)
  const baseNewPrice = MODEL_BASE_PRICES[input.model] 
    ?? (BRAND_MULTIPLIERS[input.brand] ?? 1.0) * 22000

  // 2. Apply cumulative depreciation
  let depreciatedPrice = baseNewPrice
  for (let i = 0; i < age; i++) {
    depreciatedPrice *= (1 - getDepreciationRate(i + 1))
  }

  // 3. Apply fuel adjustment
  const fuelMult = FUEL_ADJUSTMENTS[input.fuel] ?? 1.0

  // 4. Apply mileage adjustment
  const mileageMult = getMileageAdjustment(input.year, input.mileage)

  // 5. Apply brand multiplier (market premium/discount vs generic)
  const brandMult = BRAND_MULTIPLIERS[input.brand] ?? 1.0

  // 6. Base mid-price
  const rawMid = depreciatedPrice * fuelMult * mileageMult * (brandMult * 0.15 + 0.85)

  // 7. Apply condition for price spread
  const condAdj = CONDITION_ADJUSTMENTS[input.condition] ?? CONDITION_ADJUSTMENTS['bon']

  const priceMid  = Math.round(rawMid * condAdj.mid / 100) * 100
  const priceLow  = Math.round(rawMid * condAdj.low / 100) * 100
  const priceHigh = Math.round(rawMid * condAdj.high / 100) * 100

  // 8. Future depreciation
  const currentRate = getDepreciationRate(age + 1)
  const nextRate    = getDepreciationRate(age + 2)
  const dep1y = Math.round(priceMid * currentRate)
  const dep2y = Math.round(priceMid * (currentRate + nextRate * (1 - currentRate)))

  // 9. Deal score (0-100)
  // Based on: age vs price ratio, mileage quality, market demand
  let dealScore = 60  // base
  if (mileageMult > 1.05) dealScore += 10
  if (mileageMult < 0.90) dealScore -= 10
  if (input.condition === 'excellent') dealScore += 15
  if (input.condition === 'tres-bon')  dealScore += 8
  if (input.condition === 'moyen')     dealScore -= 10
  if (input.condition === 'mauvais')   dealScore -= 20
  if (input.fuel === 'hybride' || input.fuel === 'electrique') dealScore += 8
  if (input.fuel === 'diesel') dealScore -= 5
  if (['Toyota', 'Honda', 'Mazda'].includes(input.brand)) dealScore += 5
  if (['BMW', 'Mercedes', 'Audi'].includes(input.brand) && age > 4) dealScore -= 5
  dealScore = Math.max(5, Math.min(98, dealScore))

  // 10. Market trend
  let marketTrend: 'up' | 'stable' | 'down' = 'stable'
  if (input.fuel === 'electrique' || input.fuel === 'hybride') marketTrend = 'up'
  if (input.fuel === 'diesel' && age > 3) marketTrend = 'down'

  // 11. Annual costs
  const annualFuelCost = ANNUAL_FUEL_COST[input.fuel] ?? 1600
  const annualMaintCost = getAnnualMaintCost(input.brand, age, input.fuel)

  // 12. Advice
  const advice = generateAdvice(input, dealScore, marketTrend, age)

  return {
    priceLow:  Math.max(500, priceLow),
    priceMid:  Math.max(700, priceMid),
    priceHigh: Math.max(900, priceHigh),
    dealScore,
    depreciation1y: dep1y,
    depreciation2y: dep2y,
    annualFuelCost,
    annualMaintCost,
    marketTrend,
    advice,
  }
}

function generateAdvice(
  input: EstimationInput,
  dealScore: number,
  trend: string,
  age: number
): string {
  const parts: string[] = []

  if (dealScore >= 75) {
    parts.push('Excellent rapport qualité/prix pour ce véhicule.')
  } else if (dealScore >= 55) {
    parts.push('Rapport qualité/prix correct dans la moyenne du marché.')
  } else {
    parts.push('Attention : rapport qualité/prix en dessous de la moyenne.')
  }

  if (input.fuel === 'diesel' && age > 3) {
    parts.push('Les véhicules diesel perdent en attractivité dans les zones ZFE.')
  }
  if (input.fuel === 'electrique') {
    parts.push('Les véhicules électriques maintiennent bien leur valeur actuellement.')
  }
  if (age > 7 && ['BMW', 'Mercedes', 'Audi'].includes(input.brand)) {
    parts.push('Les coûts d\'entretien peuvent être élevés sur ce type de véhicule passé 7 ans.')
  }

  return parts.join(' ')
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(price)
}

export function getDealScoreLabel(score: number): { label: string; color: string } {
  if (score >= 80) return { label: 'Excellente affaire', color: 'text-emerald-400' }
  if (score >= 65) return { label: 'Bonne affaire',      color: 'text-green-400' }
  if (score >= 50) return { label: 'Prix correct',       color: 'text-yellow-400' }
  if (score >= 35) return { label: 'Prix élevé',         color: 'text-orange-400' }
  return                   { label: 'Mauvaise affaire',  color: 'text-red-400' }
}

export const BRANDS = [
  'Audi', 'BMW', 'Citroën', 'Dacia', 'Fiat', 'Ford', 'Honda',
  'Hyundai', 'Kia', 'Lexus', 'Mazda', 'Mercedes', 'Nissan', 'Opel',
  'Peugeot', 'Porsche', 'Renault', 'Seat', 'Skoda', 'Tesla',
  'Toyota', 'Volkswagen', 'Volvo',
].sort()

export const MODELS_BY_BRAND: Record<string, string[]> = {
  'Audi':       ['A1', 'A3', 'A4', 'A6', 'A8', 'Q2', 'Q3', 'Q5', 'Q7', 'TT', 'e-tron'],
  'BMW':        ['Série 1', 'Série 2', 'Série 3', 'Série 4', 'Série 5', 'X1', 'X2', 'X3', 'X5', 'X6', 'i3', 'i4'],
  'Citroën':    ['C1', 'C3', 'C3 Aircross', 'C4', 'C5 Aircross', 'Berlingo'],
  'Dacia':      ['Sandero', 'Logan', 'Duster', 'Jogger', 'Spring'],
  'Fiat':       ['500', '500X', 'Tipo', 'Panda'],
  'Ford':       ['Fiesta', 'Focus', 'Puma', 'Kuga', 'Mustang Mach-E'],
  'Honda':      ['Civic', 'HR-V', 'CR-V', 'Jazz'],
  'Hyundai':    ['i20', 'i30', 'Tucson', 'Kona', 'Santa Fe', 'IONIQ 5'],
  'Kia':        ['Picanto', 'Rio', 'Ceed', 'Sportage', 'Niro', 'EV6'],
  'Lexus':      ['CT', 'IS', 'ES', 'UX', 'NX', 'RX'],
  'Mazda':      ['Mazda2', 'Mazda3', 'CX-3', 'CX-5', 'CX-60', 'MX-5'],
  'Mercedes':   ['Classe A', 'Classe B', 'Classe C', 'Classe E', 'GLA', 'GLB', 'GLC', 'GLE'],
  'Nissan':     ['Micra', 'Juke', 'Qashqai', 'X-Trail', 'Leaf', 'Ariya'],
  'Opel':       ['Corsa', 'Astra', 'Crossland', 'Grandland', 'Mokka'],
  'Peugeot':    ['108', '208', '308', '408', '2008', '3008', '5008', 'e-208', 'Partner'],
  'Porsche':    ['911', 'Cayenne', 'Macan', 'Panamera', 'Taycan'],
  'Renault':    ['Twingo', 'Clio', 'Mégane', 'Captur', 'Kadjar', 'Koleos', 'Zoe', 'Kangoo', 'Arkana'],
  'Seat':       ['Ibiza', 'Leon', 'Arona', 'Ateca', 'Tarraco'],
  'Skoda':      ['Fabia', 'Scala', 'Octavia', 'Kamiq', 'Karoq', 'Kodiaq'],
  'Tesla':      ['Model 3', 'Model Y', 'Model S', 'Model X'],
  'Toyota':     ['Aygo', 'Yaris', 'Corolla', 'C-HR', 'RAV4', 'Camry', 'bZ4X', 'Highlander'],
  'Volkswagen': ['Polo', 'Golf', 'Passat', 'Arteon', 'T-Cross', 'T-Roc', 'Tiguan', 'Touareg', 'ID.3', 'ID.4'],
  'Volvo':      ['V40', 'V60', 'V90', 'XC40', 'XC60', 'XC90', 'C40'],
}

export const FUEL_TYPES = [
  { value: 'essence',   label: 'Essence' },
  { value: 'diesel',    label: 'Diesel' },
  { value: 'hybride',   label: 'Hybride' },
  { value: 'hybride-rechargeable', label: 'Hybride Rechargeable' },
  { value: 'electrique', label: 'Électrique' },
  { value: 'gpl',       label: 'GPL' },
]

export const CONDITIONS = [
  { value: 'excellent', label: 'Excellent',  desc: 'Comme neuf, aucun défaut visible' },
  { value: 'tres-bon',  label: 'Très bon',   desc: 'Quelques micro-rayures, très bien entretenu' },
  { value: 'bon',       label: 'Bon',        desc: 'Usure normale pour l\'âge du véhicule' },
  { value: 'moyen',     label: 'Moyen',      desc: 'Rayures, bosses mineures, usure visible' },
  { value: 'mauvais',   label: 'Mauvais',    desc: 'Dommages importants, réparations nécessaires' },
]
