// src/app/layout.tsx
import type { Metadata, Viewport } from 'next'
import { Playfair_Display, DM_Sans, DM_Mono } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/providers'

const display = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
})

const body = DM_Sans({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
})

const mono = DM_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL ?? 'https://monauto.com'),
  title: {
    default: 'MonAuto — Estimez la valeur de votre véhicule',
    template: '%s | MonAuto',
  },
  description:
    'Estimez gratuitement la valeur de votre véhicule d\'occasion en 30 secondes. Rapport premium avec analyse de marché, décote, et conseils d\'experts.',
  keywords: ['estimation voiture', 'cote voiture', 'valeur véhicule occasion', 'argus auto'],
  authors: [{ name: 'MonAuto' }],
  openGraph: {
    type: 'website',
    locale: 'fr_FR',
    url: 'https://monauto.com',
    siteName: 'MonAuto',
    title: 'MonAuto — Estimez la valeur de votre véhicule',
    description: 'Estimation professionnelle de véhicules d\'occasion. Gratuit et sans inscription.',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MonAuto — Estimation véhicule gratuite',
    description: 'Obtenez la valeur de votre voiture en 30 secondes.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
}

export const viewport: Viewport = {
  themeColor: '#0d0d10',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="font-body bg-carbon-950 text-carbon-100 antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
