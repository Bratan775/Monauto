// src/app/estimation/page.tsx
import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { EstimationForm } from '@/components/estimation/estimation-form'

export const metadata: Metadata = {
  title: 'Estimer mon véhicule',
  description: 'Estimez la valeur de votre véhicule d\'occasion gratuitement en 30 secondes.',
}

export default function EstimationPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-10">
            <p className="text-brand-400 text-sm font-semibold uppercase tracking-widest mb-3">Estimation gratuite</p>
            <h1 className="font-display text-4xl md:text-5xl font-bold text-white mb-4">
              Quelle est la valeur<br />de votre véhicule ?
            </h1>
            <p className="text-carbon-400 text-lg">
              Renseignez les informations de votre véhicule pour obtenir une estimation précise.
            </p>
          </div>
          <EstimationForm />
        </div>
      </main>
      <Footer />
    </>
  )
}
