// src/app/estimation/resultat/[id]/page.tsx
import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { prisma } from '@/lib/prisma'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { EstimationResult } from '@/components/estimation/estimation-result'

export const metadata: Metadata = {
  title: 'Résultats de votre estimation',
  robots: { index: false },
}

interface Props {
  params: { id: string }
}

export default async function EstimationResultPage({ params }: Props) {
  const estimation = await prisma.estimation.findUnique({
    where: { id: params.id },
    include: { payment: true, premiumReport: true },
  })

  if (!estimation) notFound()

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <EstimationResult estimation={estimation} />
        </div>
      </main>
      <Footer />
    </>
  )
}
