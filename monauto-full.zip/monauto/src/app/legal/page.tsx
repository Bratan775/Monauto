import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'

export const metadata: Metadata = { title: 'Mentions légales' }

export default function LegalPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="font-display text-3xl font-bold text-white mb-8">Mentions légales</h1>
          <div className="prose prose-invert prose-carbon max-w-none space-y-6 text-carbon-300">
            <section>
              <h2 className="text-xl font-semibold text-white mb-3">Éditeur du site</h2>
              <p>MonAuto SAS — Capital social : 10 000 €<br/>
              Siège social : 1 rue de la Paix, 75001 Paris, France<br/>
              RCS Paris — SIRET : 000 000 000 00000<br/>
              TVA intracommunautaire : FR00 000000000</p>
            </section>
            <section>
              <h2 className="text-xl font-semibold text-white mb-3">Hébergement</h2>
              <p>Vercel Inc. — 340 Pine Street, Suite 701, San Francisco, CA 94104, USA</p>
            </section>
            <section>
              <h2 className="text-xl font-semibold text-white mb-3">Propriété intellectuelle</h2>
              <p>L&apos;ensemble du contenu de ce site (textes, images, algorithmes) est la propriété exclusive de MonAuto SAS et est protégé par les lois françaises et internationales relatives à la propriété intellectuelle.</p>
            </section>
            <section>
              <h2 className="text-xl font-semibold text-white mb-3">Données personnelles</h2>
              <p>MonAuto SAS traite vos données personnelles conformément au RGPD. Vous disposez d&apos;un droit d&apos;accès, de rectification et de suppression. Pour exercer ces droits : privacy@monauto.com</p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
