import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'

export const metadata: Metadata = { title: 'Conditions générales d\'utilisation' }

export default function TermsPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="font-display text-3xl font-bold text-white mb-8">Conditions générales d&apos;utilisation</h1>
          <div className="space-y-6 text-carbon-300 text-sm leading-relaxed">
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">1. Objet</h2>
              <p>Les présentes CGU régissent l&apos;utilisation du service MonAuto, plateforme d&apos;estimation de véhicules d&apos;occasion accessible sur monauto.com.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">2. Nature du service</h2>
              <p>Les estimations fournies par MonAuto sont des estimations algorithmiques à titre indicatif. Elles ne constituent pas une offre d&apos;achat ou de vente, et ne remplacent pas une expertise professionnelle agréée.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">3. Compte utilisateur</h2>
              <p>Vous êtes responsable de la confidentialité de vos identifiants. Tout accès via votre compte est réputé effectué par vous.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">4. Paiement et remboursement</h2>
              <p>Le rapport premium est disponible au prix de 9,90€ TTC. Conformément à l&apos;article L221-28 du Code de la Consommation, le droit de rétractation s&apos;applique dans un délai de 14 jours. Remboursement sur demande à billing@monauto.com.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">5. Limitation de responsabilité</h2>
              <p>MonAuto SAS ne peut être tenu responsable des décisions d&apos;achat ou de vente prises sur la base des estimations fournies. Le service est fourni &quot;en l&apos;état&quot;.</p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
