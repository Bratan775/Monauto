// src/app/api/payment/checkout/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createCheckoutSession, PREMIUM_PRICE } from '@/lib/stripe'
import { z } from 'zod'

const schema = z.object({
  estimationId: z.string().cuid(),
})

export async function POST(req: NextRequest) {
  try {
    const session = await auth()
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Connexion requise', redirectTo: '/auth/login' }, { status: 401 })
    }

    const body = await req.json()
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'ID estimation invalide' }, { status: 400 })
    }

    const { estimationId } = parsed.data

    // Check estimation exists
    const estimation = await prisma.estimation.findUnique({ where: { id: estimationId } })
    if (!estimation) {
      return NextResponse.json({ error: 'Estimation introuvable' }, { status: 404 })
    }

    if (estimation.isPremium) {
      return NextResponse.json({ error: 'Rapport premium déjà acheté' }, { status: 409 })
    }

    const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000'

    const stripeSession = await createCheckoutSession(
      estimationId,
      session.user.id,
      session.user.email!,
      `${appUrl}/estimation/resultat/${estimationId}?premium=success`,
      `${appUrl}/estimation/resultat/${estimationId}?premium=cancel`,
    )

    // Record pending payment
    await prisma.payment.create({
      data: {
        userId:         session.user.id,
        estimationId,
        stripeSessionId: stripeSession.id,
        amount:          PREMIUM_PRICE,
        status:          'PENDING',
      },
    })

    return NextResponse.json({ url: stripeSession.url })
  } catch (err: any) {
    console.error('[CHECKOUT]', err)
    return NextResponse.json({ error: err.message ?? 'Erreur de paiement' }, { status: 500 })
  }
}
