// src/app/api/payment/webhook/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { prisma } from '@/lib/prisma'
import { calculateEstimation } from '@/lib/estimation-engine'
import type Stripe from 'stripe'

export const runtime = 'nodejs'

function generatePremiumReport(estimation: {
  brand: string; model: string; year: number; mileage: number;
  fuel: string; condition: string; priceMid: number;
}) {
  const result = calculateEstimation({
    brand:     estimation.brand,
    model:     estimation.model,
    year:      estimation.year,
    mileage:   estimation.mileage,
    fuel:      estimation.fuel,
    condition: estimation.condition,
  })

  const isEV = estimation.fuel === 'electrique'
  const isPremiumBrand = ['BMW', 'Mercedes', 'Audi', 'Porsche', 'Lexus'].includes(estimation.brand)

  const adviceBuy =
    result.dealScore >= 70
      ? `Excellent rapport qualité/prix. Ce ${estimation.brand} ${estimation.model} est bien positionné sur le marché. N'hésitez pas à négocier 3-5% si des travaux mineurs sont nécessaires.`
      : result.dealScore >= 50
      ? `Prix dans la moyenne du marché. Demandez l'historique complet d'entretien avant d'acheter. Une inspection par un professionnel est recommandée.`
      : `Prix au-dessus de la moyenne. Essayez de négocier à la baisse. Comparez avec d'autres annonces similaires avant de vous engager.`

  const adviceSell = isEV
    ? `Les véhicules électriques sont en forte demande. Mettez en valeur l'autonomie et l'état de la batterie. Vendez dans les 12 prochains mois pour maximiser votre prix.`
    : isPremiumBrand
    ? `Pour maximiser votre prix de vente, assurez-vous que le carnet d'entretien est à jour et faites réviser chez un concessionnaire agréé. Les acheteurs de premium sont sensibles à l'historique.`
    : `Pour vendre au meilleur prix, préparez soigneusement votre annonce avec des photos de qualité. Le prix de cession idéal se situe entre ${new Intl.NumberFormat('fr-FR').format(Math.round(estimation.priceMid * 0.97))}€ et ${new Intl.NumberFormat('fr-FR').format(Math.round(estimation.priceMid * 1.03))}€.`

  const marketComparison = {
    similar: [
      { source: 'LeBonCoin', price: Math.round(estimation.priceMid * (0.95 + Math.random() * 0.1)), mileage: estimation.mileage + Math.floor(Math.random() * 10000 - 5000) },
      { source: 'AutoScout24', price: Math.round(estimation.priceMid * (0.92 + Math.random() * 0.16)), mileage: estimation.mileage + Math.floor(Math.random() * 15000 - 7500) },
      { source: 'La Centrale', price: Math.round(estimation.priceMid * (0.93 + Math.random() * 0.14)), mileage: estimation.mileage + Math.floor(Math.random() * 12000 - 6000) },
    ],
  }

  return {
    depreciation1y:  result.depreciation1y,
    depreciation2y:  result.depreciation2y,
    annualFuelCost:  result.annualFuelCost,
    annualMaintCost: result.annualMaintCost,
    marketComparison,
    adviceBuy,
    adviceSell,
  }
}

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = req.headers.get('stripe-signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err: any) {
    console.error('[WEBHOOK] Signature invalide:', err.message)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session
    const { estimationId, userId } = session.metadata ?? {}

    if (!estimationId || !userId) {
      console.error('[WEBHOOK] Metadata manquante')
      return NextResponse.json({ error: 'Missing metadata' }, { status: 400 })
    }

    try {
      const estimation = await prisma.estimation.findUnique({ where: { id: estimationId } })
      if (!estimation) throw new Error('Estimation not found')

      const report = generatePremiumReport({
        brand:     estimation.brand,
        model:     estimation.model,
        year:      estimation.year,
        mileage:   estimation.mileage,
        fuel:      estimation.fuel,
        condition: estimation.condition,
        priceMid:  estimation.priceMid,
      })

      // Update in transaction
      await prisma.$transaction([
        prisma.payment.update({
          where:  { stripeSessionId: session.id },
          data:   { status: 'COMPLETED', stripePaymentId: session.payment_intent as string },
        }),
        prisma.estimation.update({
          where: { id: estimationId },
          data:  { isPremium: true },
        }),
        prisma.premiumReport.create({
          data: {
            estimationId,
            ...report,
          },
        }),
      ])

      console.log(`[WEBHOOK] Premium report generated for estimation ${estimationId}`)
    } catch (err: any) {
      console.error('[WEBHOOK] Error processing payment:', err)
      return NextResponse.json({ error: 'Processing error' }, { status: 500 })
    }
  }

  return NextResponse.json({ received: true })
}
