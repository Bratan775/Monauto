// src/app/api/estimate/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { calculateEstimation } from '@/lib/estimation-engine'
import { auth } from '@/lib/auth'

const schema = z.object({
  brand:     z.string().min(1).max(50),
  model:     z.string().min(1).max(50),
  year:      z.number().int().min(2000).max(new Date().getFullYear()),
  mileage:   z.number().int().min(0).max(500000),
  fuel:      z.enum(['essence', 'diesel', 'hybride', 'hybride-rechargeable', 'electrique', 'gpl', 'hydrogene']),
  condition: z.enum(['excellent', 'tres-bon', 'bon', 'moyen', 'mauvais']),
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const parsed = schema.safeParse(body)

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Données invalides', details: parsed.error.flatten() },
        { status: 400 }
      )
    }

    const input = parsed.data
    const result = calculateEstimation(input)
    const session = await auth()

    const estimation = await prisma.estimation.create({
      data: {
        userId:    session?.user?.id ?? null,
        brand:     input.brand,
        model:     input.model,
        year:      input.year,
        mileage:   input.mileage,
        fuel:      input.fuel,
        condition: input.condition,
        priceLow:  result.priceLow,
        priceMid:  result.priceMid,
        priceHigh: result.priceHigh,
        dealScore: result.dealScore,
        isPremium: false,
      },
    })

    return NextResponse.json({ id: estimation.id, ...result })
  } catch (err: any) {
    console.error('[ESTIMATE]', err)
    return NextResponse.json({ error: err.message ?? 'Erreur interne' }, { status: 500 })
  }
}
