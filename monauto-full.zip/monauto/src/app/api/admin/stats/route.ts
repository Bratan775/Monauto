import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await auth()
  if (!session?.user?.id || session.user.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Accès refusé' }, { status: 403 })
  }

  const [userCount, estimationCount, payments] = await Promise.all([
    prisma.user.count(),
    prisma.estimation.count(),
    prisma.payment.findMany({ where: { status: 'COMPLETED' }, select: { amount: true } }),
  ])

  const revenue = payments.reduce((a, p) => a + p.amount, 0) / 100

  return NextResponse.json({ userCount, estimationCount, revenue })
}
