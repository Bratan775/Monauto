// src/app/auth/login/page.tsx
import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { LoginForm } from '@/components/auth/login-form'

export const metadata: Metadata = {
  title: 'Connexion',
  robots: { index: false },
}

export default function LoginPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 flex items-center justify-center pt-16 px-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="font-display text-3xl font-bold text-white mb-2">Bon retour !</h1>
            <p className="text-carbon-400">Connectez-vous à votre compte MonAuto</p>
          </div>
          <LoginForm />
        </div>
      </main>
    </>
  )
}
