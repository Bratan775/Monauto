// src/app/auth/register/page.tsx
import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { RegisterForm } from '@/components/auth/register-form'

export const metadata: Metadata = {
  title: 'Créer un compte',
  robots: { index: false },
}

export default function RegisterPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 flex items-center justify-center pt-16 px-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="font-display text-3xl font-bold text-white mb-2">Créer un compte</h1>
            <p className="text-carbon-400">Rejoignez MonAuto et sauvegardez vos estimations</p>
          </div>
          <RegisterForm />
        </div>
      </main>
    </>
  )
}
