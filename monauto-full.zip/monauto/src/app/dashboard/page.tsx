import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { DashboardContent } from '@/components/dashboard/dashboard-content'

export const metadata: Metadata = {
  title: 'Mon tableau de bord',
  robots: { index: false },
}

export default async function DashboardPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/login?callbackUrl=/dashboard')

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: {
      estimations: {
        orderBy: { createdAt: 'desc' },
        take: 20,
        include: { payment: true, premiumReport: true },
      },
      _count: { select: { estimations: true, payments: true } },
    },
  })

  if (!user) redirect('/auth/login')

  const premiumCount = user.estimations.filter(e => e.isPremium).length
  const totalSpent = user.estimations
    .filter(e => e.payment?.status === 'COMPLETED')
    .reduce((acc, e) => acc + (e.payment?.amount ?? 0), 0) / 100

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <DashboardContent
            user={{
              id: user.id,
              name: user.name,
              email: user.email,
              createdAt: user.createdAt.toISOString(),
            }}
            estimations={user.estimations.map(e => ({
              ...e,
              createdAt: e.createdAt.toISOString(),
              payment: e.payment ? { ...e.payment, createdAt: e.payment.createdAt.toISOString(), updatedAt: e.payment.updatedAt.toISOString() } : null,
              premiumReport: e.premiumReport ? { ...e.premiumReport, createdAt: e.premiumReport.createdAt.toISOString() } : null,
            }))}
            stats={{
              total: user._count.estimations,
              premium: premiumCount,
              totalSpent,
            }}
          />
        </div>
      </main>
      <Footer />
    </>
  )
}
