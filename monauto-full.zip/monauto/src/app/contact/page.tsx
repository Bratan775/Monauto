import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import { Mail, MessageSquare, Clock } from 'lucide-react'

export const metadata: Metadata = { title: 'Contact' }

export default function ContactPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-12">
            <h1 className="font-display text-4xl font-bold text-white mb-4">Contactez-nous</h1>
            <p className="text-carbon-400">Notre équipe est disponible pour vous aider.</p>
          </div>

          <div className="grid gap-4 mb-10">
            {[
              { icon: <Mail className="w-5 h-5" />, label: 'Email général', value: 'contact@monauto.com', color: 'text-brand-400', bg: 'bg-brand-600/15' },
              { icon: <MessageSquare className="w-5 h-5" />, label: 'Support technique', value: 'support@monauto.com', color: 'text-purple-400', bg: 'bg-purple-600/15' },
              { icon: <Clock className="w-5 h-5" />, label: 'Horaires', value: 'Lun–Ven 9h–18h', color: 'text-green-400', bg: 'bg-green-600/15' },
            ].map(({ icon, label, value, color, bg }) => (
              <div key={label} className="card-base p-5 flex items-center gap-4">
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${bg} ${color} flex-shrink-0`}>{icon}</div>
                <div>
                  <p className="text-carbon-500 text-xs mb-0.5">{label}</p>
                  <p className={`font-medium ${color}`}>{value}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="card-base p-6 text-center">
            <p className="text-carbon-400 text-sm">
              Pour les questions de facturation ou remboursement :{' '}
              <a href="mailto:billing@monauto.com" className="text-brand-400 hover:text-brand-300">billing@monauto.com</a>
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
