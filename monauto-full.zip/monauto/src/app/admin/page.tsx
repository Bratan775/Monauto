import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { Navbar } from '@/components/layout/navbar'
import { AdminContent } from '@/components/admin/admin-content'

export const metadata: Metadata = {
  title: 'Administration',
  robots: { index: false },
}

export default async function AdminPage() {
  const session = await auth()
  if (!session?.user?.id) redirect('/auth/login')
  if (session.user.role !== 'ADMIN') redirect('/dashboard')

  const [users, estimations, payments] = await Promise.all([
    prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: { _count: { select: { estimations: true } } },
    }),
    prisma.estimation.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: { user: { select: { name: true, email: true } } },
    }),
    prisma.payment.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50,
      include: { user: { select: { name: true, email: true } } },
    }),
  ])

  const totalRevenue = payments
    .filter(p => p.status === 'COMPLETED')
    .reduce((acc, p) => acc + p.amount, 0) / 100

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <AdminContent
            users={users.map(u => ({ ...u, createdAt: u.createdAt.toISOString(), updatedAt: u.updatedAt.toISOString(), emailVerified: u.emailVerified?.toISOString() ?? null }))}
            estimations={estimations.map(e => ({ ...e, createdAt: e.createdAt.toISOString() }))}
            payments={payments.map(p => ({ ...p, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() }))}
            stats={{ totalUsers: users.length, totalEstimations: estimations.length, totalRevenue }}
          />
        </div>
      </main>
    </>
  )
}
