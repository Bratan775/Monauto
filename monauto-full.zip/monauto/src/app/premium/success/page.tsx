import type { Metadata } from 'next'
import Link from 'next/link'
import { CheckCircle, ArrowRight, Star } from 'lucide-react'
import { Navbar } from '@/components/layout/navbar'

export const metadata: Metadata = {
  title: 'Paiement confirmé — Rapport Premium activé',
  robots: { index: false },
}

export default function PremiumSuccessPage({
  searchParams,
}: {
  searchParams: { estimationId?: string }
}) {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 flex items-center justify-center pt-16 px-4">
        <div className="max-w-md w-full text-center">
          <div className="w-20 h-20 rounded-full bg-accent-gold/20 border-2 border-accent-gold/40 flex items-center justify-center mx-auto mb-6 animate-fade-in">
            <CheckCircle className="w-10 h-10 text-accent-gold" />
          </div>

          <h1 className="font-display text-3xl font-bold text-white mb-3 animate-fade-up">
            Rapport Premium activé !
          </h1>
          <p className="text-carbon-400 mb-8 animate-fade-up animate-delay-100 animate-fill-both">
            Votre paiement a été confirmé. Votre rapport complet est maintenant disponible
            avec l&apos;analyse détaillée, la décote sur 2 ans et les conseils personnalisés.
          </p>

          <div className="card-base p-5 mb-6 text-left animate-fade-up animate-delay-200 animate-fill-both">
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-4 h-4 text-accent-gold" />
              <span className="text-sm font-semibold text-white">Inclus dans votre rapport</span>
            </div>
            {[
              'Estimation basse / moyenne / haute',
              'Score bonne affaire détaillé',
              'Décote projetée sur 1 et 2 ans',
              'Coûts carburant + entretien annuels',
              'Comparaison avec le marché',
              'Conseils achat / revente personnalisés',
            ].map(f => (
              <div key={f} className="flex items-center gap-2 text-sm text-carbon-300 mb-2">
                <CheckCircle className="w-3.5 h-3.5 text-green-500 flex-shrink-0" /> {f}
              </div>
            ))}
          </div>

          <div className="flex flex-col gap-3 animate-fade-up animate-delay-300 animate-fill-both">
            {searchParams.estimationId && (
              <Link href={`/estimation/resultat/${searchParams.estimationId}`} className="btn-premium">
                Voir mon rapport <ArrowRight className="w-4 h-4" />
              </Link>
            )}
            <Link href="/dashboard" className="btn-secondary">
              Mon tableau de bord
            </Link>
          </div>
        </div>
      </main>
    </>
  )
}
