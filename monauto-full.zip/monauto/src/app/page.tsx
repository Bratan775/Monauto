// src/app/page.tsx
import type { Metadata } from 'next'
import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'
import {
  ArrowRight, Star, Shield, Zap, TrendingUp, CheckCircle,
  ChevronDown, BarChart3, Clock, Lock, Award
} from 'lucide-react'

export const metadata: Metadata = {
  title: 'MonAuto — Estimez la valeur de votre véhicule gratuitement',
  description: 'Estimez la valeur de votre voiture en 30 secondes. Algorithme expert, rapport premium avec analyse de décote, conseils achat/revente.',
}

const testimonials = [
  {
    name: 'Thomas D.',
    role: 'Particulier, Paris',
    avatar: 'T',
    text: 'J\'ai vendu ma Golf 20% plus cher grâce au rapport premium. L\'analyse de marché était bluffante de précision.',
    rating: 5,
  },
  {
    name: 'Sarah M.',
    role: 'Acheteuse, Lyon',
    avatar: 'S',
    text: 'Le score "bonne affaire" m\'a évité d\'acheter une voiture surévaluée. Interface claire et résultats en quelques secondes.',
    rating: 5,
  },
  {
    name: 'Marc B.',
    role: 'Professionnel automobile',
    avatar: 'M',
    text: 'Outil indispensable pour mes clients. Les estimations sont cohérentes avec le marché réel. Je le recommande systématiquement.',
    rating: 5,
  },
  {
    name: 'Julie R.',
    role: 'Particulière, Bordeaux',
    avatar: 'J',
    text: 'Enfin un site simple et efficace ! J\'ai obtenu 3 estimations différentes pour négocier. Excellent rapport qualité/prix.',
    rating: 5,
  },
]

const faqs = [
  {
    q: 'Comment fonctionne l\'estimation ?',
    a: 'Notre algorithme analyse votre véhicule selon 6 critères : marque, modèle, année, kilométrage, carburant et état. Il croise ces données avec notre base de prix de marché de plus de 40 véhicules et des règles de dépréciation expertes pour générer une fourchette de prix crédible.',
  },
  {
    q: 'L\'estimation gratuite est-elle fiable ?',
    a: 'Oui. L\'estimation gratuite vous donne une fourchette basse/moyenne/haute basée sur notre moteur de calcul. Pour une analyse complète avec décote sur 2 ans, coûts annuels et comparaison marché, optez pour le rapport premium.',
  },
  {
    q: 'Qu\'est-ce que le rapport premium inclut ?',
    a: 'Le rapport premium (9,90€) inclut : estimation détaillée, score "bonne affaire", projection de décote sur 2 ans, coût annuel carburant + entretien, comparaison avec le marché, et conseils personnalisés achat/revente.',
  },
  {
    q: 'Mes données sont-elles sécurisées ?',
    a: 'Absolument. Vos données sont chiffrées, jamais revendues, et vous pouvez supprimer votre compte à tout moment. Les paiements sont traités par Stripe (certifié PCI DSS niveau 1).',
  },
  {
    q: 'Puis-je utiliser MonAuto sans créer de compte ?',
    a: 'Oui, l\'estimation simple est disponible sans inscription. Cependant, créer un compte vous permet de sauvegarder vos estimations et accéder à votre historique.',
  },
  {
    q: 'Le rapport premium est-il remboursable ?',
    a: 'Oui, nous offrons un remboursement sous 14 jours si vous n\'êtes pas satisfait, conformément au droit de rétractation européen.',
  },
]

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        {/* HERO */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-carbon-950">
          {/* Background effects */}
          <div className="absolute inset-0 bg-dot-pattern opacity-40" />
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-600/10 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute top-1/2 right-0 w-[400px] h-[400px] bg-brand-800/8 rounded-full blur-[80px] pointer-events-none" />

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-800 bg-brand-950/50 text-brand-300 text-xs font-medium mb-8 animate-fade-in">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
              Estimation professionnelle en 30 secondes
            </div>

            {/* Title */}
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-[0.95] tracking-tight mb-6 animate-fade-up">
              Connaissez la vraie{' '}
              <br />
              <span className="gradient-text">valeur de votre auto</span>
            </h1>

            <p className="section-subtitle max-w-2xl mx-auto mb-10 animate-fade-up animate-delay-100 animate-fill-both">
              MonAuto analyse votre véhicule d&apos;occasion avec précision. 
              Obtenez une fourchette de prix crédible, un score bonne affaire 
              et des conseils experts — gratuitement.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up animate-delay-200 animate-fill-both">
              <Link href="/estimation" className="btn-primary text-base py-4 px-8 shadow-brand-glow">
                Estimer mon véhicule
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a href="#comment-ca-marche" className="btn-secondary text-base py-4 px-8">
                Comment ça marche
              </a>
            </div>

            {/* Trust signals */}
            <div className="flex flex-wrap items-center justify-center gap-6 mt-12 text-xs text-carbon-500 animate-fade-up animate-delay-300 animate-fill-both">
              <div className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-green-500" /> Données sécurisées
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-yellow-500" /> Résultat instantané
              </div>
              <div className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-brand-400" /> Sans engagement
              </div>
              <div className="flex items-center gap-1.5">
                <Star className="w-3.5 h-3.5 text-accent-gold" />
                <span>4.9/5 · +8 000 estimations</span>
              </div>
            </div>

            {/* Mock result card preview */}
            <div className="mt-16 max-w-2xl mx-auto animate-fade-up animate-delay-400 animate-fill-both">
              <div className="card-base p-6 border-gradient relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand-500/50 to-transparent" />
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-xs text-carbon-500 mb-1">Estimation basse</p>
                    <p className="font-display text-2xl font-bold text-carbon-300">14 200€</p>
                  </div>
                  <div className="text-center border-x border-carbon-800">
                    <p className="text-xs text-carbon-400 mb-1">Valeur marchande</p>
                    <p className="font-display text-3xl font-bold text-white">16 800€</p>
                    <div className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-full bg-green-500/15 text-green-400 text-xs">
                      <TrendingUp className="w-3 h-3" /> Bonne affaire
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-carbon-500 mb-1">Estimation haute</p>
                    <p className="font-display text-2xl font-bold text-carbon-300">18 500€</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-carbon-800 grid grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center gap-2 text-carbon-400">
                    <div className="w-6 h-6 rounded-lg bg-emerald-500/15 flex items-center justify-center">
                      <span className="text-emerald-400 text-[10px] font-bold">82</span>
                    </div>
                    Score bonne affaire
                  </div>
                  <div className="flex items-center gap-2 text-carbon-400">
                    <div className="w-6 h-6 rounded-lg bg-brand-500/15 flex items-center justify-center">
                      <TrendingUp className="w-3 h-3 text-brand-400" />
                    </div>
                    Décote: -1 680€/an
                  </div>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-carbon-950/20 pointer-events-none" />
              </div>
              <p className="text-xs text-carbon-600 mt-2">Exemple : Peugeot 308, 2020, 45 000km, diesel, bon état</p>
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
            <ChevronDown className="w-5 h-5 text-carbon-600" />
          </div>
        </section>

        {/* STATS */}
        <section className="py-12 border-y border-carbon-800 bg-carbon-900/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {[
                { value: '8 200+', label: 'Estimations réalisées' },
                { value: '96%', label: 'Taux de satisfaction' },
                { value: '40+', label: 'Modèles en base' },
                { value: '9,90€', label: 'Rapport premium' },
              ].map(({ value, label }) => (
                <div key={label}>
                  <p className="font-display text-3xl md:text-4xl font-bold text-white mb-1">{value}</p>
                  <p className="text-carbon-500 text-sm">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section id="comment-ca-marche" className="py-24 bg-carbon-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <p className="text-brand-400 text-sm font-semibold uppercase tracking-widest mb-3">Processus</p>
              <h2 className="section-title">Comment ça marche ?</h2>
              <p className="section-subtitle mt-4 max-w-xl mx-auto">
                Trois étapes simples pour connaître la valeur exacte de votre véhicule.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  step: '01',
                  icon: <Clock className="w-6 h-6" />,
                  title: 'Renseignez votre véhicule',
                  desc: 'Marque, modèle, année, kilométrage, carburant et état du véhicule. 30 secondes suffisent.',
                  color: 'brand',
                },
                {
                  step: '02',
                  icon: <BarChart3 className="w-6 h-6" />,
                  title: 'Notre algorithme calcule',
                  desc: 'Notre moteur croise 12 variables de marché pour estimer une fourchette de prix précise et crédible.',
                  color: 'brand',
                },
                {
                  step: '03',
                  icon: <Award className="w-6 h-6" />,
                  title: 'Obtenez votre estimation',
                  desc: 'Gratuit : fourchette basse/haute + score. Premium : rapport complet avec décote, conseils et analyse.',
                  color: 'brand',
                },
              ].map(({ step, icon, title, desc }) => (
                <div key={step} className="card-hover p-6 group">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 rounded-xl bg-brand-600/20 border border-brand-700/30 flex items-center justify-center text-brand-400 group-hover:bg-brand-600/30 transition-colors">
                        {icon}
                      </div>
                    </div>
                    <div>
                      <span className="text-xs font-mono text-brand-500 font-semibold">{step}</span>
                      <h3 className="text-lg font-semibold text-white mt-1 mb-2">{title}</h3>
                      <p className="text-carbon-400 text-sm leading-relaxed">{desc}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 text-center">
              <Link href="/estimation" className="btn-primary">
                Commencer maintenant <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* PRICING */}
        <section id="tarifs" className="py-24 bg-carbon-900/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <p className="text-brand-400 text-sm font-semibold uppercase tracking-widest mb-3">Tarifs</p>
              <h2 className="section-title">Transparent & sans surprise</h2>
            </div>

            <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
              {/* Free */}
              <div className="card-base p-8">
                <h3 className="text-lg font-semibold text-white mb-1">Estimation gratuite</h3>
                <p className="text-carbon-500 text-sm mb-6">Pour une première idée du prix</p>
                <div className="mb-6">
                  <span className="font-display text-5xl font-bold text-white">0€</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {[
                    'Fourchette basse / moyenne / haute',
                    'Score bonne affaire',
                    'Estimation décote annuelle',
                    'Coût annuel estimatif',
                    'Sans inscription requise',
                  ].map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-carbon-300">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" /> {f}
                    </li>
                  ))}
                </ul>
                <Link href="/estimation" className="btn-secondary w-full text-center">
                  Estimer gratuitement
                </Link>
              </div>

              {/* Premium */}
              <div className="relative card-base p-8 border-accent-gold/30 bg-gradient-to-b from-carbon-900 to-carbon-950">
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-accent-gold/50 to-transparent" />
                <div className="absolute -top-3 right-6">
                  <span className="px-3 py-1 rounded-full bg-accent-gold text-carbon-950 text-xs font-bold">
                    POPULAIRE
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">Rapport Premium</h3>
                <p className="text-carbon-500 text-sm mb-6">Pour acheter ou vendre au meilleur prix</p>
                <div className="mb-6 flex items-end gap-1">
                  <span className="font-display text-5xl font-bold text-white">9,90€</span>
                  <span className="text-carbon-500 text-sm mb-1">/ rapport</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {[
                    'Tout de l\'estimation gratuite',
                    'Analyse de décote sur 2 ans',
                    'Coût carburant + entretien détaillé',
                    'Comparaison marché local',
                    'Conseils achat / revente personnalisés',
                    'PDF téléchargeable',
                    'Support prioritaire',
                  ].map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-carbon-300">
                      <CheckCircle className="w-4 h-4 text-accent-gold flex-shrink-0 mt-0.5" /> {f}
                    </li>
                  ))}
                </ul>
                <Link href="/estimation" className="btn-premium w-full text-center">
                  Obtenir le rapport premium
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="py-24 bg-carbon-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <p className="text-brand-400 text-sm font-semibold uppercase tracking-widest mb-3">Témoignages</p>
              <h2 className="section-title">Ils nous font confiance</h2>
              <div className="flex items-center justify-center gap-1 mt-4">
                {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-accent-gold text-accent-gold" />)}
                <span className="text-carbon-400 text-sm ml-2">4,9/5 sur +8 200 estimations</span>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {testimonials.map((t) => (
                <div key={t.name} className="card-hover p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-9 h-9 rounded-full bg-brand-700 flex items-center justify-center text-sm font-bold text-white">
                      {t.avatar}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{t.name}</p>
                      <p className="text-xs text-carbon-500">{t.role}</p>
                    </div>
                  </div>
                  <div className="flex gap-0.5 mb-3">
                    {Array.from({ length: t.rating }).map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-accent-gold text-accent-gold" />
                    ))}
                  </div>
                  <p className="text-carbon-400 text-sm leading-relaxed">&ldquo;{t.text}&rdquo;</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="py-24 bg-carbon-900/20">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <p className="text-brand-400 text-sm font-semibold uppercase tracking-widest mb-3">FAQ</p>
              <h2 className="section-title">Questions fréquentes</h2>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, i) => (
                <details key={i} className="card-base group">
                  <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
                    <span className="font-medium text-white text-sm">{faq.q}</span>
                    <ChevronDown className="w-4 h-4 text-carbon-500 group-open:rotate-180 transition-transform flex-shrink-0 ml-4" />
                  </summary>
                  <div className="px-5 pb-5 text-sm text-carbon-400 leading-relaxed border-t border-carbon-800 pt-4">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* CTA FINAL */}
        <section className="py-24 bg-carbon-950 relative overflow-hidden">
          <div className="absolute inset-0 bg-dot-pattern opacity-20" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-700/8 rounded-full blur-[100px]" />
          <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="section-title mb-4">
              Prêt à connaître la valeur<br />
              <span className="gradient-text">de votre véhicule ?</span>
            </h2>
            <p className="section-subtitle mb-8">
              Rejoignez +8 000 utilisateurs qui font confiance à MonAuto pour leurs estimations.
            </p>
            <Link href="/estimation" className="btn-primary text-base py-4 px-10 shadow-brand-glow">
              Estimer mon véhicule gratuitement
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
