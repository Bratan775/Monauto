import Link from 'next/link'
import { Navbar } from '@/components/layout/navbar'
import { ArrowRight } from 'lucide-react'

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 flex items-center justify-center px-4">
        <div className="text-center">
          <p className="font-mono text-8xl font-bold text-carbon-800 mb-4">404</p>
          <h1 className="font-display text-3xl font-bold text-white mb-3">Page introuvable</h1>
          <p className="text-carbon-400 mb-8">La page que vous recherchez n&apos;existe pas ou a été déplacée.</p>
          <Link href="/" className="btn-primary">
            Retour à l&apos;accueil <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </main>
    </>
  )
}
