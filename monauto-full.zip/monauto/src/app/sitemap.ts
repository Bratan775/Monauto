import type { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const base = 'https://monauto.com'
  const now = new Date()

  return [
    { url: base, lastModified: now, changeFrequency: 'weekly', priority: 1 },
    { url: `${base}/estimation`, lastModified: now, changeFrequency: 'monthly', priority: 0.9 },
    { url: `${base}/auth/login`, lastModified: now, changeFrequency: 'yearly', priority: 0.3 },
    { url: `${base}/auth/register`, lastModified: now, changeFrequency: 'yearly', priority: 0.4 },
    { url: `${base}/legal`, lastModified: now, changeFrequency: 'yearly', priority: 0.1 },
    { url: `${base}/privacy`, lastModified: now, changeFrequency: 'yearly', priority: 0.1 },
    { url: `${base}/terms`, lastModified: now, changeFrequency: 'yearly', priority: 0.1 },
    { url: `${base}/contact`, lastModified: now, changeFrequency: 'yearly', priority: 0.2 },
  ]
}
