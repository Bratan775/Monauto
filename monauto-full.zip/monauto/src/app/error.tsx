'use client'
import Link from 'next/link'
import { useEffect } from 'react'

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  useEffect(() => { console.error(error) }, [error])

  return (
    <main className="min-h-screen bg-carbon-950 flex items-center justify-center px-4">
      <div className="text-center">
        <p className="font-mono text-6xl font-bold text-carbon-800 mb-4">500</p>
        <h1 className="font-display text-2xl font-bold text-white mb-3">Une erreur est survenue</h1>
        <p className="text-carbon-400 mb-8">{error.message}</p>
        <div className="flex gap-3 justify-center">
          <button onClick={reset} className="btn-primary">Réessayer</button>
          <Link href="/" className="btn-secondary">Accueil</Link>
        </div>
      </div>
    </main>
  )
}
