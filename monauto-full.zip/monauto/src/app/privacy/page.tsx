import type { Metadata } from 'next'
import { Navbar } from '@/components/layout/navbar'
import { Footer } from '@/components/layout/footer'

export const metadata: Metadata = { title: 'Politique de confidentialité' }

export default function PrivacyPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-carbon-950 pt-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="font-display text-3xl font-bold text-white mb-8">Politique de confidentialité</h1>
          <div className="space-y-6 text-carbon-300 text-sm leading-relaxed">
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">1. Données collectées</h2>
              <p>Nous collectons les informations que vous nous fournissez lors de l&apos;inscription (nom, email), vos estimations de véhicules, et les données de navigation anonymisées (via cookies techniques).</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">2. Utilisation des données</h2>
              <p>Vos données sont utilisées pour fournir le service d&apos;estimation, améliorer notre algorithme (de manière anonymisée), et vous envoyer les confirmations de paiement. Nous ne vendons jamais vos données.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">3. Partage des données</h2>
              <p>Vos données peuvent être partagées avec Stripe (paiements, PCI DSS niveau 1) et Vercel (hébergement). Ces prestataires sont soumis à des accords de traitement conformes au RGPD.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">4. Vos droits</h2>
              <p>Conformément au RGPD, vous disposez d&apos;un droit d&apos;accès, rectification, effacement, portabilité et opposition. Contactez-nous à privacy@monauto.com.</p>
            </section>
            <section>
              <h2 className="text-lg font-semibold text-white mb-2">5. Conservation</h2>
              <p>Vos données sont conservées pendant la durée de votre compte + 3 ans. Les données de paiement sont conservées 10 ans (obligations légales).</p>
            </section>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
