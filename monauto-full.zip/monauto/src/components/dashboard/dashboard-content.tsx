'use client'
import Link from 'next/link'
import { formatPrice } from '@/lib/utils'
import { FUEL_TYPES, CONDITIONS, getDealScoreLabel } from '@/lib/estimation-engine'
import { Car, TrendingUp, CreditCard, Plus, ExternalLink, Award, Calendar, Gauge, Fuel } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Props {
  user: { id: string; name: string | null; email: string | null; createdAt: string }
  estimations: any[]
  stats: { total: number; premium: number; totalSpent: number }
}

export function DashboardContent({ user, estimations, stats }: Props) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-carbon-500 text-sm mb-1">Tableau de bord</p>
          <h1 className="font-display text-3xl font-bold text-white">
            Bonjour, {user.name?.split(' ')[0] ?? 'vous'} 👋
          </h1>
          <p className="text-carbon-400 text-sm mt-1">{user.email}</p>
        </div>
        <Link href="/estimation" className="btn-primary text-sm py-2.5 px-4">
          <Plus className="w-4 h-4" /> Nouvelle estimation
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          {
            icon: <Car className="w-5 h-5" />,
            label: 'Estimations réalisées',
            value: stats.total,
            color: 'text-brand-400',
            bg: 'bg-brand-600/15',
          },
          {
            icon: <Award className="w-5 h-5" />,
            label: 'Rapports premium',
            value: stats.premium,
            color: 'text-accent-gold',
            bg: 'bg-yellow-500/15',
          },
          {
            icon: <CreditCard className="w-5 h-5" />,
            label: 'Total dépensé',
            value: `${stats.totalSpent.toFixed(2)}€`,
            color: 'text-green-400',
            bg: 'bg-green-500/15',
          },
        ].map(({ icon, label, value, color, bg }) => (
          <div key={label} className="card-base p-5 flex items-center gap-4">
            <div className={cn('w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0', bg, color)}>
              {icon}
            </div>
            <div>
              <p className="text-carbon-500 text-xs mb-0.5">{label}</p>
              <p className={cn('text-xl font-bold', color)}>{value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Estimations list */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">Mes estimations</h2>
          <span className="text-xs text-carbon-500">{stats.total} au total</span>
        </div>

        {estimations.length === 0 ? (
          <div className="card-base p-12 text-center">
            <Car className="w-12 h-12 text-carbon-700 mx-auto mb-4" />
            <p className="text-carbon-400 mb-4">Aucune estimation pour le moment</p>
            <Link href="/estimation" className="btn-primary text-sm">
              Estimer mon premier véhicule
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {estimations.map((e) => {
              const dealLabel = getDealScoreLabel(e.dealScore)
              const fuelLabel = FUEL_TYPES.find(f => f.value === e.fuel)?.label ?? e.fuel
              const condLabel = CONDITIONS.find(c => c.value === e.condition)?.label ?? e.condition
              const date = new Date(e.createdAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })

              return (
                <Link key={e.id} href={`/estimation/resultat/${e.id}`}
                  className="card-hover p-5 flex items-center gap-4 group block">
                  <div className="w-10 h-10 rounded-xl bg-brand-600/20 flex items-center justify-center flex-shrink-0 group-hover:bg-brand-600/30 transition-colors">
                    <Car className="w-5 h-5 text-brand-400" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold text-white text-sm">{e.brand} {e.model} {e.year}</p>
                      {e.isPremium && (
                        <span className="px-1.5 py-0.5 rounded-full bg-accent-gold/20 text-accent-gold text-[10px] font-bold uppercase">
                          PREMIUM
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-carbon-500 flex-wrap">
                      <span className="flex items-center gap-1"><Gauge className="w-3 h-3" />{e.mileage.toLocaleString('fr-FR')} km</span>
                      <span className="flex items-center gap-1"><Fuel className="w-3 h-3" />{fuelLabel}</span>
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{date}</span>
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0 hidden sm:block">
                    <p className="font-bold text-white">{formatPrice(e.priceMid)}</p>
                    <p className={cn('text-xs', dealLabel.color)}>{dealLabel.label}</p>
                  </div>

                  <ExternalLink className="w-4 h-4 text-carbon-600 group-hover:text-carbon-400 transition-colors flex-shrink-0" />
                </Link>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
