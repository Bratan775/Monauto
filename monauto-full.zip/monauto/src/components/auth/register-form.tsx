'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { signIn } from 'next-auth/react'
import Link from 'next/link'
import { Eye, EyeOff, Loader2, Mail, Lock, User, CheckCircle } from 'lucide-react'

export function RegisterForm() {
  const router = useRouter()
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const pwdChecks = {
    length:    form.password.length >= 8,
    uppercase: /[A-Z]/.test(form.password),
    digit:     /\d/.test(form.password),
  }
  const pwdValid = Object.values(pwdChecks).every(Boolean)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!pwdValid) return
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()

      if (!res.ok) throw new Error(data.error)

      await signIn('credentials', {
        email: form.email,
        password: form.password,
        redirect: false,
      })
      router.push('/dashboard')
    } catch (err: any) {
      setError(err.message)
      setLoading(false)
    }
  }

  return (
    <div className="card-base p-8">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label-base">Votre prénom</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-carbon-500" />
            <input type="text" value={form.name}
              onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
              placeholder="Jean" required className="input-base pl-10" />
          </div>
        </div>

        <div>
          <label className="label-base">Adresse email</label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-carbon-500" />
            <input type="email" value={form.email}
              onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
              placeholder="vous@exemple.fr" required className="input-base pl-10" />
          </div>
        </div>

        <div>
          <label className="label-base">Mot de passe</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-carbon-500" />
            <input type={showPwd ? 'text' : 'password'} value={form.password}
              onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
              placeholder="••••••••" required className="input-base pl-10 pr-10" />
            <button type="button" onClick={() => setShowPwd(v => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-carbon-500 hover:text-carbon-300">
              {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {form.password.length > 0 && (
            <div className="mt-2 space-y-1">
              {[
                { key: 'length', label: '8 caractères minimum' },
                { key: 'uppercase', label: 'Une majuscule' },
                { key: 'digit', label: 'Un chiffre' },
              ].map(({ key, label }) => (
                <div key={key} className="flex items-center gap-1.5 text-xs">
                  <CheckCircle className={`w-3 h-3 ${pwdChecks[key as keyof typeof pwdChecks] ? 'text-green-500' : 'text-carbon-700'}`} />
                  <span className={pwdChecks[key as keyof typeof pwdChecks] ? 'text-green-400' : 'text-carbon-600'}>{label}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">{error}</div>
        )}

        <button type="submit" disabled={loading || !pwdValid || !form.name || !form.email}
          className="btn-primary w-full disabled:opacity-40 mt-2">
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Création…</> : 'Créer mon compte'}
        </button>
      </form>

      <div className="mt-6 pt-6 border-t border-carbon-800 text-center">
        <p className="text-sm text-carbon-500">
          Déjà un compte ?{' '}
          <Link href="/auth/login" className="text-brand-400 hover:text-brand-300 font-medium">Se connecter</Link>
        </p>
      </div>
    </div>
  )
}
