// src/components/estimation/estimation-result.tsx
'use client'
import { useState } from 'react'
import Link from 'next/link'
import type { Estimation, Payment, PremiumReport } from '@prisma/client'
import { formatPrice, cn } from '@/lib/utils'
import { getDealScoreLabel, FUEL_TYPES, CONDITIONS } from '@/lib/estimation-engine'
import {
  TrendingDown, TrendingUp, Minus, Lock, CheckCircle,
  RefreshCcw, Share2, ArrowRight, Star, Fuel, Wrench,
  BarChart3, Lightbulb, Calendar, Gauge
} from 'lucide-react'

interface Props {
  estimation: Estimation & { payment?: Payment | null; premiumReport?: PremiumReport | null }
}

export function EstimationResult({ estimation: e }: Props) {
  const [loadingPayment, setLoadingPayment] = useState(false)
  const dealLabel = getDealScoreLabel(e.dealScore)
  const hasPremium = e.isPremium && e.premiumReport
  const fuelLabel = FUEL_TYPES.find(f => f.value === e.fuel)?.label ?? e.fuel
  const condLabel = CONDITIONS.find(c => c.value === e.condition)?.label ?? e.condition

  const handleBuyPremium = async () => {
    setLoadingPayment(true)
    try {
      const res = await fetch('/api/payment/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estimationId: e.id }),
      })
      const data = await res.json()
      if (data.url) window.location.href = data.url
      else throw new Error(data.error ?? 'Erreur paiement')
    } catch (err: any) {
      alert(err.message)
      setLoadingPayment(false)
    }
  }

  const scoreColor = e.dealScore >= 70
    ? 'text-emerald-400'
    : e.dealScore >= 50
    ? 'text-yellow-400'
    : 'text-red-400'

  const scoreBg = e.dealScore >= 70
    ? 'bg-emerald-500/15 border-emerald-500/30'
    : e.dealScore >= 50
    ? 'bg-yellow-500/15 border-yellow-500/30'
    : 'bg-red-500/15 border-red-500/30'

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-brand-400 text-sm font-semibold uppercase tracking-widest mb-1">Estimation</p>
          <h1 className="font-display text-3xl md:text-4xl font-bold text-white">
            {e.brand} {e.model}
          </h1>
          <div className="flex items-center gap-3 mt-2 text-sm text-carbon-400">
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> {e.year}
            </span>
            <span className="flex items-center gap-1">
              <Gauge className="w-3.5 h-3.5" /> {e.mileage.toLocaleString('fr-FR')} km
            </span>
            <span className="flex items-center gap-1">
              <Fuel className="w-3.5 h-3.5" /> {fuelLabel}
            </span>
          </div>
        </div>
        <Link href="/estimation" className="btn-secondary text-xs py-2 px-3 flex-shrink-0">
          <RefreshCcw className="w-3.5 h-3.5" /> Nouvelle estimation
        </Link>
      </div>

      {/* Main price card */}
      <div className="card-base border-gradient relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand-500/60 to-transparent" />
        <div className="p-6 md:p-8">
          <div className="grid grid-cols-3 gap-4 md:gap-8">
            <div className="text-center">
              <p className="text-xs text-carbon-500 mb-2 uppercase tracking-wide">Basse</p>
              <p className="font-display text-xl md:text-3xl font-bold text-carbon-400">
                {formatPrice(e.priceLow)}
              </p>
              <p className="text-xs text-carbon-600 mt-1">Estimation conservatrice</p>
            </div>

            <div className="text-center border-x border-carbon-800 px-2 md:px-4">
              <p className="text-xs text-carbon-400 mb-2 uppercase tracking-wide">Valeur marché</p>
              <p className="font-display text-3xl md:text-5xl font-bold text-white">
                {formatPrice(e.priceMid)}
              </p>
              <div className={cn('inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full border text-xs font-semibold', scoreBg, scoreColor)}>
                <Star className="w-3 h-3" /> {dealLabel.label}
              </div>
            </div>

            <div className="text-center">
              <p className="text-xs text-carbon-500 mb-2 uppercase tracking-wide">Haute</p>
              <p className="font-display text-xl md:text-3xl font-bold text-carbon-400">
                {formatPrice(e.priceHigh)}
              </p>
              <p className="text-xs text-carbon-600 mt-1">Excellent état / rare</p>
            </div>
          </div>

          {/* Score bar */}
          <div className="mt-6 pt-6 border-t border-carbon-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-carbon-400">Score bonne affaire</span>
              <span className={cn('text-lg font-bold', scoreColor)}>{e.dealScore}/100</span>
            </div>
            <div className="w-full h-2 bg-carbon-800 rounded-full overflow-hidden">
              <div
                className={cn(
                  'h-full rounded-full transition-all duration-1000',
                  e.dealScore >= 70 ? 'bg-emerald-500' :
                  e.dealScore >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                )}
                style={{ width: `${e.dealScore}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            icon: <TrendingDown className="w-4 h-4" />,
            label: 'Décote annuelle',
            value: `-${formatPrice(e.priceMid * 0.09)}`,
            color: 'text-orange-400',
            bg: 'bg-orange-500/10',
          },
          {
            icon: <Fuel className="w-4 h-4" />,
            label: 'Carburant / an',
            value: formatPrice(e.fuel === 'electrique' ? 650 : e.fuel === 'diesel' ? 1400 : 1800),
            color: 'text-blue-400',
            bg: 'bg-blue-500/10',
          },
          {
            icon: <Wrench className="w-4 h-4" />,
            label: 'Entretien / an',
            value: formatPrice(['BMW','Mercedes','Audi','Porsche'].includes(e.brand) ? 1400 : 900),
            color: 'text-purple-400',
            bg: 'bg-purple-500/10',
          },
          {
            icon: <BarChart3 className="w-4 h-4" />,
            label: 'État déclaré',
            value: condLabel,
            color: 'text-carbon-300',
            bg: 'bg-carbon-800',
          },
        ].map(({ icon, label, value, color, bg }) => (
          <div key={label} className="card-base p-4">
            <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center mb-3', bg, color)}>
              {icon}
            </div>
            <p className="text-xs text-carbon-500 mb-0.5">{label}</p>
            <p className={cn('font-semibold text-sm', color)}>{value}</p>
          </div>
        ))}
      </div>

      {/* Premium upsell or Premium report */}
      {!hasPremium ? (
        <div className="card-base border-accent-gold/20 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-accent-gold/50 to-transparent" />
          <div className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Lock className="w-4 h-4 text-accent-gold" />
                  <span className="text-accent-gold text-sm font-semibold uppercase tracking-wide">Rapport Premium</span>
                </div>
                <h2 className="text-xl font-bold text-white mb-3">
                  Débloquez l&apos;analyse complète
                </h2>
                <ul className="space-y-2">
                  {[
                    'Décote projetée sur 2 ans',
                    'Coûts carburant + entretien détaillés',
                    'Comparaison avec 5 annonces similaires',
                    'Conseils personnalisés achat / revente',
                    'PDF téléchargeable',
                  ].map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-carbon-300">
                      <CheckCircle className="w-3.5 h-3.5 text-accent-gold flex-shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex-shrink-0 text-center">
                <p className="text-carbon-500 text-sm mb-1">Paiement unique</p>
                <p className="font-display text-4xl font-bold text-white mb-4">9,90€</p>
                <button
                  onClick={handleBuyPremium}
                  disabled={loadingPayment}
                  className="btn-premium disabled:opacity-60 whitespace-nowrap"
                >
                  {loadingPayment ? 'Redirection…' : 'Obtenir le rapport'}
                  {!loadingPayment && <ArrowRight className="w-4 h-4" />}
                </button>
                <p className="text-xs text-carbon-600 mt-2">Paiement sécurisé par Stripe</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        // Premium report content
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-accent-gold" />
            <h2 className="text-lg font-bold text-white">Rapport Premium</h2>
            <span className="px-2 py-0.5 rounded-full bg-accent-gold/20 text-accent-gold text-xs font-semibold">DÉBLOQUÉ</span>
          </div>

          {e.premiumReport && (
            <>
              {/* Depreciation */}
              <div className="card-base p-5">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <TrendingDown className="w-4 h-4 text-orange-400" /> Projection de décote
                </h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-xs text-carbon-500 mb-1">Aujourd&apos;hui</p>
                    <p className="font-bold text-white">{formatPrice(e.priceMid)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-carbon-500 mb-1">Dans 1 an</p>
                    <p className="font-bold text-orange-400">
                      {formatPrice(e.priceMid - e.premiumReport.depreciation1y)}
                    </p>
                    <p className="text-xs text-orange-500">-{formatPrice(e.premiumReport.depreciation1y)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-carbon-500 mb-1">Dans 2 ans</p>
                    <p className="font-bold text-red-400">
                      {formatPrice(e.priceMid - e.premiumReport.depreciation2y)}
                    </p>
                    <p className="text-xs text-red-500">-{formatPrice(e.premiumReport.depreciation2y)}</p>
                  </div>
                </div>
              </div>

              {/* Annual costs */}
              <div className="card-base p-5">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-blue-400" /> Coûts annuels estimés
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-carbon-400 flex items-center gap-2">
                      <Fuel className="w-3.5 h-3.5" /> Carburant (15 000 km/an)
                    </span>
                    <span className="font-semibold text-white">{formatPrice(e.premiumReport.annualFuelCost)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-carbon-400 flex items-center gap-2">
                      <Wrench className="w-3.5 h-3.5" /> Entretien & réparations
                    </span>
                    <span className="font-semibold text-white">{formatPrice(e.premiumReport.annualMaintCost)}</span>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-carbon-800">
                    <span className="text-sm font-semibold text-white">Total annuel</span>
                    <span className="font-bold text-brand-400">
                      {formatPrice(e.premiumReport.annualFuelCost + e.premiumReport.annualMaintCost)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Advice */}
              <div className="card-base p-5">
                <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-accent-gold" /> Conseils personnalisés
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-green-400 font-semibold uppercase tracking-wide mb-2">Achat</p>
                    <p className="text-sm text-carbon-300 leading-relaxed">{e.premiumReport.adviceBuy}</p>
                  </div>
                  <div>
                    <p className="text-xs text-orange-400 font-semibold uppercase tracking-wide mb-2">Revente</p>
                    <p className="text-sm text-carbon-300 leading-relaxed">{e.premiumReport.adviceSell}</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pt-4 border-t border-carbon-800">
        <Link href="/dashboard" className="text-sm text-carbon-500 hover:text-white transition-colors">
          Voir mes estimations →
        </Link>
        <button
          onClick={() => navigator.share?.({ title: 'Mon estimation MonAuto', url: window.location.href })}
          className="flex items-center gap-1.5 text-sm text-carbon-500 hover:text-white transition-colors"
        >
          <Share2 className="w-3.5 h-3.5" /> Partager
        </button>
      </div>
    </div>
  )
}
