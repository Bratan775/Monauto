// src/components/estimation/estimation-form.tsx
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { BRANDS, MODELS_BY_BRAND, FUEL_TYPES, CONDITIONS } from '@/lib/estimation-engine'
import { cn } from '@/lib/utils'
import { Car, Gauge, Calendar, Fuel, Star, ArrowRight, Loader2 } from 'lucide-react'

const CURRENT_YEAR = new Date().getFullYear()
const YEARS = Array.from({ length: 25 }, (_, i) => CURRENT_YEAR - i)

interface FormData {
  brand: string
  model: string
  year: string
  mileage: string
  fuel: string
  condition: string
}

export function EstimationForm() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState<FormData>({
    brand: '', model: '', year: '', mileage: '', fuel: '', condition: ''
  })

  const update = (field: keyof FormData, value: string) => {
    setForm(prev => {
      const next = { ...prev, [field]: value }
      if (field === 'brand') next.model = ''  // reset model on brand change
      return next
    })
    setError('')
  }

  const models = form.brand ? (MODELS_BY_BRAND[form.brand] ?? []) : []

  const canProceedStep1 = form.brand && form.model && form.year
  const canProceedStep2 = form.mileage && form.fuel
  const canSubmit = form.condition

  const handleSubmit = async () => {
    if (!canSubmit) return
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/estimate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brand:     form.brand,
          model:     form.model,
          year:      parseInt(form.year),
          mileage:   parseInt(form.mileage.replace(/\s/g, '')),
          fuel:      form.fuel,
          condition: form.condition,
        }),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error ?? 'Erreur lors de l\'estimation')
      }

      const data = await res.json()
      router.push(`/estimation/resultat/${data.id}`)
    } catch (e: any) {
      setError(e.message)
      setLoading(false)
    }
  }

  return (
    <div className="card-base p-6 md:p-8">
      {/* Progress */}
      <div className="flex items-center gap-2 mb-8">
        {[1, 2, 3].map(s => (
          <div key={s} className="flex items-center gap-2 flex-1">
            <div className={cn(
              'w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all',
              step > s  ? 'bg-brand-600 text-white' :
              step === s ? 'bg-brand-600 text-white ring-2 ring-brand-400/30' :
                           'bg-carbon-800 text-carbon-500'
            )}>
              {step > s ? '✓' : s}
            </div>
            <span className={cn(
              'text-xs font-medium hidden sm:block',
              step >= s ? 'text-white' : 'text-carbon-600'
            )}>
              {s === 1 ? 'Véhicule' : s === 2 ? 'Kilométrage' : 'État'}
            </span>
            {s < 3 && <div className={cn('flex-1 h-px', step > s ? 'bg-brand-600' : 'bg-carbon-800')} />}
          </div>
        ))}
      </div>

      {/* STEP 1: Brand / Model / Year */}
      {step === 1 && (
        <div className="space-y-5 animate-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-brand-600/20 flex items-center justify-center">
              <Car className="w-4 h-4 text-brand-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">Votre véhicule</h2>
          </div>

          {/* Brand */}
          <div>
            <label className="label-base">Marque *</label>
            <select
              value={form.brand}
              onChange={e => update('brand', e.target.value)}
              className="input-base"
            >
              <option value="">Sélectionnez une marque</option>
              {BRANDS.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>

          {/* Model */}
          <div>
            <label className="label-base">Modèle *</label>
            <select
              value={form.model}
              onChange={e => update('model', e.target.value)}
              className="input-base"
              disabled={!form.brand}
            >
              <option value="">
                {form.brand ? 'Sélectionnez un modèle' : 'Choisissez d\'abord une marque'}
              </option>
              {models.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            {form.brand && !form.model && (
              <p className="text-xs text-carbon-500 mt-1.5">
                Votre modèle n&apos;est pas dans la liste ? Choisissez le plus proche.
              </p>
            )}
          </div>

          {/* Year */}
          <div>
            <label className="label-base">Année de mise en circulation *</label>
            <select
              value={form.year}
              onChange={e => update('year', e.target.value)}
              className="input-base"
            >
              <option value="">Sélectionnez l&apos;année</option>
              {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>
      )}

      {/* STEP 2: Mileage + Fuel */}
      {step === 2 && (
        <div className="space-y-5 animate-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-brand-600/20 flex items-center justify-center">
              <Gauge className="w-4 h-4 text-brand-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">Kilométrage & carburant</h2>
          </div>

          {/* Summary */}
          <div className="p-4 rounded-xl bg-carbon-900 border border-carbon-800 flex items-center gap-3">
            <Car className="w-4 h-4 text-brand-400 flex-shrink-0" />
            <span className="text-sm text-carbon-300">
              {form.brand} {form.model} — {form.year}
            </span>
          </div>

          {/* Mileage */}
          <div>
            <label className="label-base">
              Kilométrage actuel *
              <span className="text-carbon-600 font-normal ml-1">(km)</span>
            </label>
            <input
              type="number"
              value={form.mileage}
              onChange={e => update('mileage', e.target.value)}
              placeholder="Ex: 85000"
              min="0"
              max="500000"
              className="input-base"
            />
            {form.mileage && (
              <p className="text-xs text-carbon-500 mt-1.5">
                Soit ~{Math.round(parseInt(form.mileage) / (CURRENT_YEAR - parseInt(form.year) || 1)).toLocaleString('fr-FR')} km/an
              </p>
            )}
          </div>

          {/* Fuel */}
          <div>
            <label className="label-base">Type de carburant *</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {FUEL_TYPES.map(f => (
                <button
                  key={f.value}
                  type="button"
                  onClick={() => update('fuel', f.value)}
                  className={cn(
                    'p-3 rounded-xl border text-sm font-medium transition-all text-left',
                    form.fuel === f.value
                      ? 'border-brand-500 bg-brand-600/15 text-white'
                      : 'border-carbon-700 bg-carbon-900 text-carbon-400 hover:border-carbon-500'
                  )}
                >
                  <Fuel className={cn('w-4 h-4 mb-1', form.fuel === f.value ? 'text-brand-400' : 'text-carbon-600')} />
                  {f.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STEP 3: Condition */}
      {step === 3 && (
        <div className="space-y-5 animate-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-brand-600/20 flex items-center justify-center">
              <Star className="w-4 h-4 text-brand-400" />
            </div>
            <h2 className="text-lg font-semibold text-white">État du véhicule</h2>
          </div>

          {/* Summary */}
          <div className="p-4 rounded-xl bg-carbon-900 border border-carbon-800 grid grid-cols-2 gap-2 text-sm">
            <span className="text-carbon-500">Véhicule</span>
            <span className="text-white">{form.brand} {form.model}</span>
            <span className="text-carbon-500">Année / KM</span>
            <span className="text-white">{form.year} · {parseInt(form.mileage).toLocaleString('fr-FR')} km</span>
            <span className="text-carbon-500">Carburant</span>
            <span className="text-white capitalize">{FUEL_TYPES.find(f => f.value === form.fuel)?.label}</span>
          </div>

          {/* Condition */}
          <div>
            <label className="label-base mb-3">État général du véhicule *</label>
            <div className="space-y-2">
              {CONDITIONS.map(c => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => update('condition', c.value)}
                  className={cn(
                    'w-full p-4 rounded-xl border text-left transition-all',
                    form.condition === c.value
                      ? 'border-brand-500 bg-brand-600/10'
                      : 'border-carbon-700 bg-carbon-900 hover:border-carbon-500'
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className={cn(
                      'font-semibold text-sm',
                      form.condition === c.value ? 'text-white' : 'text-carbon-200'
                    )}>
                      {c.label}
                    </span>
                    {form.condition === c.value && (
                      <div className="w-4 h-4 rounded-full bg-brand-500 flex items-center justify-center">
                        <div className="w-2 h-2 rounded-full bg-white" />
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-carbon-500 mt-0.5">{c.desc}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
          {error}
        </div>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between mt-8 pt-6 border-t border-carbon-800">
        {step > 1 ? (
          <button
            type="button"
            onClick={() => setStep(s => s - 1)}
            className="btn-secondary text-sm py-2.5 px-5"
          >
            ← Retour
          </button>
        ) : <div />}

        {step < 3 ? (
          <button
            type="button"
            onClick={() => setStep(s => s + 1)}
            disabled={step === 1 ? !canProceedStep1 : !canProceedStep2}
            className="btn-primary text-sm py-2.5 px-5 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Continuer <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!canSubmit || loading}
            className="btn-primary text-sm py-2.5 px-6 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Calcul en cours…</>
            ) : (
              <>Obtenir mon estimation <ArrowRight className="w-4 h-4" /></>
            )}
          </button>
        )}
      </div>
    </div>
  )
}
