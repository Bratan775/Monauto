// src/components/layout/navbar.tsx
'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { Menu, X, ChevronDown, User, LogOut, LayoutDashboard, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

export function Navbar() {
  const { data: session } = useSession()
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        scrolled
          ? 'bg-carbon-950/90 backdrop-blur-xl border-b border-carbon-800'
          : 'bg-transparent'
      )}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center group-hover:bg-brand-500 transition-colors">
            <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-white" stroke="currentColor" strokeWidth={2}>
              <path d="M5 17H3a2 2 0 01-2-2V9a2 2 0 012-2h1l3-4h8l3 4h1a2 2 0 012 2v6a2 2 0 01-2 2h-2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="7.5" cy="17.5" r="2.5"/>
              <circle cx="16.5" cy="17.5" r="2.5"/>
            </svg>
          </div>
          <span className="font-display font-bold text-xl text-white">
            Mon<span className="text-brand-400">Auto</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="/#comment-ca-marche" className="text-sm text-carbon-400 hover:text-white transition-colors">
            Comment ça marche
          </Link>
          <Link href="/#tarifs" className="text-sm text-carbon-400 hover:text-white transition-colors">
            Tarifs
          </Link>
          <Link href="/#faq" className="text-sm text-carbon-400 hover:text-white transition-colors">
            FAQ
          </Link>
        </div>

        {/* CTA + Auth */}
        <div className="hidden md:flex items-center gap-3">
          <Link href="/estimation" className="btn-primary text-sm py-2 px-4">
            Estimer mon véhicule
          </Link>

          {session ? (
            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-3 py-2 rounded-xl border border-carbon-700 hover:border-carbon-500 transition-colors text-sm text-carbon-300"
              >
                <div className="w-6 h-6 rounded-full bg-brand-700 flex items-center justify-center text-xs font-bold text-white">
                  {session.user.name?.[0]?.toUpperCase() ?? 'U'}
                </div>
                <span className="hidden lg:block">{session.user.name}</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {profileOpen && (
                <div className="absolute right-0 top-full mt-2 w-52 card-base shadow-xl py-1 z-50">
                  <Link href="/dashboard" onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-carbon-300 hover:text-white hover:bg-carbon-800 transition-colors">
                    <LayoutDashboard className="w-4 h-4" /> Mon tableau de bord
                  </Link>
                  {session.user.role === 'ADMIN' && (
                    <Link href="/admin" onClick={() => setProfileOpen(false)}
                      className="flex items-center gap-2 px-4 py-2.5 text-sm text-carbon-300 hover:text-white hover:bg-carbon-800 transition-colors">
                      <Settings className="w-4 h-4" /> Administration
                    </Link>
                  )}
                  <hr className="my-1 border-carbon-800" />
                  <button
                    onClick={() => { signOut({ callbackUrl: '/' }); setProfileOpen(false) }}
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-red-400 hover:text-red-300 hover:bg-carbon-800 transition-colors w-full text-left"
                  >
                    <LogOut className="w-4 h-4" /> Se déconnecter
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link href="/auth/login" className="btn-secondary text-sm py-2 px-4">
              Connexion
            </Link>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="md:hidden p-2 rounded-lg text-carbon-400 hover:text-white"
        >
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-carbon-950 border-b border-carbon-800 px-4 py-4 space-y-3">
          <Link href="/#comment-ca-marche" onClick={() => setMenuOpen(false)}
            className="block text-carbon-400 hover:text-white py-2 text-sm">Comment ça marche</Link>
          <Link href="/#tarifs" onClick={() => setMenuOpen(false)}
            className="block text-carbon-400 hover:text-white py-2 text-sm">Tarifs</Link>
          <Link href="/#faq" onClick={() => setMenuOpen(false)}
            className="block text-carbon-400 hover:text-white py-2 text-sm">FAQ</Link>
          <hr className="border-carbon-800" />
          <Link href="/estimation" onClick={() => setMenuOpen(false)} className="btn-primary w-full text-sm">
            Estimer mon véhicule
          </Link>
          {session ? (
            <>
              <Link href="/dashboard" onClick={() => setMenuOpen(false)} className="btn-secondary w-full text-sm">
                Mon tableau de bord
              </Link>
              <button onClick={() => signOut({ callbackUrl: '/' })}
                className="w-full text-sm text-red-400 py-2">Se déconnecter</button>
            </>
          ) : (
            <Link href="/auth/login" onClick={() => setMenuOpen(false)} className="btn-secondary w-full text-sm">
              Connexion
            </Link>
          )}
        </div>
      )}
    </header>
  )
}
