// src/components/layout/footer.tsx
import Link from 'next/link'

export function Footer() {
  return (
    <footer className="border-t border-carbon-800 bg-carbon-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center">
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-white" stroke="currentColor" strokeWidth={2}>
                  <path d="M5 17H3a2 2 0 01-2-2V9a2 2 0 012-2h1l3-4h8l3 4h1a2 2 0 012 2v6a2 2 0 01-2 2h-2" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="7.5" cy="17.5" r="2.5"/>
                  <circle cx="16.5" cy="17.5" r="2.5"/>
                </svg>
              </div>
              <span className="font-display font-bold text-xl text-white">
                Mon<span className="text-brand-400">Auto</span>
              </span>
            </div>
            <p className="text-carbon-400 text-sm max-w-xs leading-relaxed">
              La référence française pour estimer la valeur de votre véhicule d&apos;occasion.
              Précis, rapide, fiable.
            </p>
            <div className="flex items-center gap-3 mt-4">
              <div className="w-8 h-8 rounded-lg bg-carbon-800 flex items-center justify-center hover:bg-carbon-700 transition-colors cursor-pointer">
                <span className="text-xs font-bold text-carbon-300">𝕏</span>
              </div>
              <div className="w-8 h-8 rounded-lg bg-carbon-800 flex items-center justify-center hover:bg-carbon-700 transition-colors cursor-pointer">
                <span className="text-xs font-bold text-carbon-300">in</span>
              </div>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Produit</h4>
            <ul className="space-y-2.5">
              {[
                ['Estimation gratuite', '/estimation'],
                ['Rapport premium', '/#tarifs'],
                ['Comment ça marche', '/#comment-ca-marche'],
                ['FAQ', '/#faq'],
              ].map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-sm text-carbon-400 hover:text-white transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Légal</h4>
            <ul className="space-y-2.5">
              {[
                ['Mentions légales', '/legal'],
                ['Politique de confidentialité', '/privacy'],
                ['CGU', '/terms'],
                ['Contact', '/contact'],
              ].map(([label, href]) => (
                <li key={href}>
                  <Link href={href} className="text-sm text-carbon-400 hover:text-white transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-carbon-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-carbon-500 text-xs">
            © {new Date().getFullYear()} MonAuto SAS. Tous droits réservés.
          </p>
          <p className="text-carbon-600 text-xs">
            Paiements sécurisés par{' '}
            <span className="text-carbon-400 font-medium">Stripe</span>
          </p>
        </div>
      </div>
    </footer>
  )
}
