'use client'
import { useState } from 'react'
import { formatPrice, cn } from '@/lib/utils'
import { Users, Car, CreditCard, TrendingUp, CheckCircle, Clock, XCircle, Shield } from 'lucide-react'

type Tab = 'overview' | 'users' | 'estimations' | 'payments'

interface Props {
  users: any[]
  estimations: any[]
  payments: any[]
  stats: { totalUsers: number; totalEstimations: number; totalRevenue: number }
}

export function AdminContent({ users, estimations, payments, stats }: Props) {
  const [tab, setTab] = useState<Tab>('overview')

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'users', label: `Utilisateurs (${stats.totalUsers})`, icon: <Users className="w-4 h-4" /> },
    { id: 'estimations', label: `Estimations (${stats.totalEstimations})`, icon: <Car className="w-4 h-4" /> },
    { id: 'payments', label: `Paiements (${payments.length})`, icon: <CreditCard className="w-4 h-4" /> },
  ]

  const completedPayments = payments.filter(p => p.status === 'COMPLETED').length

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-red-600/20 flex items-center justify-center">
          <Shield className="w-5 h-5 text-red-400" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold text-white">Administration</h1>
          <p className="text-carbon-500 text-sm">Panneau de contrôle MonAuto</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-carbon-900 rounded-xl w-fit flex-wrap">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all',
              tab === t.id ? 'bg-brand-600 text-white' : 'text-carbon-400 hover:text-white'
            )}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Utilisateurs', value: stats.totalUsers, icon: <Users className="w-5 h-5" />, color: 'text-brand-400', bg: 'bg-brand-600/15' },
              { label: 'Estimations', value: stats.totalEstimations, icon: <Car className="w-5 h-5" />, color: 'text-purple-400', bg: 'bg-purple-600/15' },
              { label: 'Paiements réussis', value: completedPayments, icon: <CheckCircle className="w-5 h-5" />, color: 'text-green-400', bg: 'bg-green-600/15' },
              { label: 'Revenus totaux', value: `${stats.totalRevenue.toFixed(2)}€`, icon: <CreditCard className="w-5 h-5" />, color: 'text-accent-gold', bg: 'bg-yellow-600/15' },
            ].map(({ label, value, icon, color, bg }) => (
              <div key={label} className="card-base p-5">
                <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center mb-3', bg, color)}>{icon}</div>
                <p className="text-carbon-500 text-xs mb-1">{label}</p>
                <p className={cn('text-2xl font-bold', color)}>{value}</p>
              </div>
            ))}
          </div>

          {/* Recent activity */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="card-base p-5">
              <h3 className="font-semibold text-white mb-4">Derniers utilisateurs</h3>
              <div className="space-y-3">
                {users.slice(0, 5).map(u => (
                  <div key={u.id} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-brand-700 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                      {u.name?.[0]?.toUpperCase() ?? 'U'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white truncate">{u.name ?? 'Anonyme'}</p>
                      <p className="text-xs text-carbon-500 truncate">{u.email}</p>
                    </div>
                    <span className="text-xs text-carbon-600">{u._count.estimations} est.</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="card-base p-5">
              <h3 className="font-semibold text-white mb-4">Derniers paiements</h3>
              <div className="space-y-3">
                {payments.slice(0, 5).map(p => (
                  <div key={p.id} className="flex items-center gap-3">
                    <div className={cn('w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0',
                      p.status === 'COMPLETED' ? 'bg-green-600/20' : 'bg-yellow-600/20')}>
                      {p.status === 'COMPLETED'
                        ? <CheckCircle className="w-4 h-4 text-green-400" />
                        : <Clock className="w-4 h-4 text-yellow-400" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white truncate">{p.user?.name ?? 'Anonyme'}</p>
                      <p className="text-xs text-carbon-500">{new Date(p.createdAt).toLocaleDateString('fr-FR')}</p>
                    </div>
                    <span className="text-sm font-semibold text-white">{(p.amount / 100).toFixed(2)}€</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Users tab */}
      {tab === 'users' && (
        <div className="card-base overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-carbon-800">
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Utilisateur</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Rôle</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Estimations</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Inscrit le</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id} className="border-b border-carbon-800/50 hover:bg-carbon-900/50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-brand-700/50 flex items-center justify-center text-xs font-bold text-brand-300">
                          {u.name?.[0]?.toUpperCase() ?? 'U'}
                        </div>
                        <div>
                          <p className="text-white font-medium">{u.name ?? 'Anonyme'}</p>
                          <p className="text-carbon-500 text-xs">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium',
                        u.role === 'ADMIN' ? 'bg-red-500/20 text-red-400' : 'bg-carbon-800 text-carbon-400')}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-carbon-300">{u._count.estimations}</td>
                    <td className="px-4 py-3 text-carbon-500">
                      {new Date(u.createdAt).toLocaleDateString('fr-FR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Estimations tab */}
      {tab === 'estimations' && (
        <div className="card-base overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-carbon-800">
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Véhicule</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Utilisateur</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Prix moyen</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Type</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {estimations.map(e => (
                  <tr key={e.id} className="border-b border-carbon-800/50 hover:bg-carbon-900/50 transition-colors">
                    <td className="px-4 py-3">
                      <p className="text-white font-medium">{e.brand} {e.model}</p>
                      <p className="text-carbon-500 text-xs">{e.year} · {e.mileage.toLocaleString('fr-FR')} km</p>
                    </td>
                    <td className="px-4 py-3 text-carbon-400">{e.user?.name ?? 'Anonyme'}</td>
                    <td className="px-4 py-3 text-white font-semibold">{formatPrice(e.priceMid)}</td>
                    <td className="px-4 py-3">
                      <span className={cn('px-2 py-0.5 rounded-full text-xs font-medium',
                        e.isPremium ? 'bg-yellow-500/20 text-yellow-400' : 'bg-carbon-800 text-carbon-400')}>
                        {e.isPremium ? 'PREMIUM' : 'GRATUIT'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-carbon-500">
                      {new Date(e.createdAt).toLocaleDateString('fr-FR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Payments tab */}
      {tab === 'payments' && (
        <div className="card-base overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-carbon-800">
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Utilisateur</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Montant</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Statut</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Stripe ID</th>
                  <th className="text-left px-4 py-3 text-carbon-500 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {payments.map(p => (
                  <tr key={p.id} className="border-b border-carbon-800/50 hover:bg-carbon-900/50 transition-colors">
                    <td className="px-4 py-3">
                      <p className="text-white">{p.user?.name ?? 'Anonyme'}</p>
                      <p className="text-carbon-500 text-xs">{p.user?.email}</p>
                    </td>
                    <td className="px-4 py-3 text-white font-semibold">{(p.amount / 100).toFixed(2)}€</td>
                    <td className="px-4 py-3">
                      <span className={cn('flex items-center gap-1 w-fit px-2 py-0.5 rounded-full text-xs font-medium',
                        p.status === 'COMPLETED' ? 'bg-green-500/20 text-green-400' :
                        p.status === 'PENDING'   ? 'bg-yellow-500/20 text-yellow-400' :
                                                    'bg-red-500/20 text-red-400')}>
                        {p.status === 'COMPLETED' ? <CheckCircle className="w-3 h-3" /> :
                         p.status === 'PENDING'   ? <Clock className="w-3 h-3" /> :
                                                    <XCircle className="w-3 h-3" />}
                        {p.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-carbon-500 font-mono text-xs truncate max-w-[120px]">
                      {p.stripeSessionId.slice(0, 20)}…
                    </td>
                    <td className="px-4 py-3 text-carbon-500">
                      {new Date(p.createdAt).toLocaleDateString('fr-FR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
