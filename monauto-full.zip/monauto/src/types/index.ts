// src/types/index.ts
import type { User, Estimation, Payment, PremiumReport } from '@prisma/client'

export type { User, Estimation, Payment, PremiumReport }

export interface EstimationWithDetails extends Estimation {
  payment?: Payment | null
  premiumReport?: PremiumReport | null
}

export interface UserWithEstimations extends User {
  estimations: EstimationWithDetails[]
  _count: { estimations: number; payments: number }
}

declare module 'next-auth' {
  interface User {
    role?: string
  }
  interface Session {
    user: {
      id: string
      name?: string | null
      email?: string | null
      image?: string | null
      role?: string
    }
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id?: string
    role?: string
  }
}
